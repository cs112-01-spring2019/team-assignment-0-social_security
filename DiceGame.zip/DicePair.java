import java.util.*;

public class DicePair{
	//Die die1, die2;
	//int sum;
	
	public static void main(String[] args){
		Die die1, die2;
		int sum;
		die1 = new Die();
		die2 = new Die();

		die1.roll();
		die2.roll();
		sum = die1.getFaceValue() + die2.getFaceValue();
		System.out.println("the sum is: " + sum + " the dice 1 result was: " + die1 + " result of die 2: " + die2);

	}
}